db.createUser(
    {
        user: "fdrennan",
        pwd: "thirdday1",
        roles: [
            {
                role: "admin",
                db: "admin"
            }
        ]
    }
);
